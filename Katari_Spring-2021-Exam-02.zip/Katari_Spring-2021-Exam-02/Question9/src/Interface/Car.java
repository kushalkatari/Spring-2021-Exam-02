/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;
import java.io.*;

/**
 * @author Kushal Satya Durgaji Katari
 */

    
    interface Vehicle {
      
    // all are the abstract methods.
  public  void Gear(int a);
  public  void speed(int a);
   public void Brakes(int a);
     }
  
public class Car implements Vehicle{
      
    int speed;
    int gear;
      
     // to change gear
    @Override
    public void Gear(int newGear){
          
        gear = newGear;
    }
      
    // to increase speed
    @Override
    public void speed(int increment){
          
        speed = speed + increment;
    }
      
    // to decrease speed
    @Override
    public void Brakes(int decrement){
          
        speed = speed - decrement;
    }
      
    public void printStates() {
         System.out.println("speed: " + speed
              + " gear: " + gear);
    }
}


