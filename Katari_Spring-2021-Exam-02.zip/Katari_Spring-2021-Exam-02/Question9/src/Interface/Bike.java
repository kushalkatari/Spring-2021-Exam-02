/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

/**
 * @author Kushal Satya Durgaji Katari
 */

   public class Bike implements Vehicle 
   {     
    int speed;
    int gear;     
    // to change gear
    @Override
    public void Gear(int Gear)
      {        
        gear = Gear;
      }
      
    // to increase speed
    @Override
    public void speed(int inc)
       { 
        speed = speed + inc;
       }
      
    // to decrease speed
    @Override
    public void Brakes(int dec)
        {        
        speed = speed - dec;
        }
      
    public void printStates()
        {
         System.out.println("speed: " + speed+ " gear: " + gear);
        }     
        }
