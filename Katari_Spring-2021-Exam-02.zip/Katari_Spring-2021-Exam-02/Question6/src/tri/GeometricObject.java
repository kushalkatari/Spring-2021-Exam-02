/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tri;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
public class GeometricObject 
{
	private String color = "white";
	private boolean filled;
	private java.util.Date dateCreated;

	/**  geometric object  */
	public GeometricObject() 
        {
		dateCreated = new java.util.Date();
	}

	/** Constructor for geometricObject for color and is filled */
	public GeometricObject(String color, boolean filled)
        {
		dateCreated = new java.util.Date();
		this.color = color;
		this.filled = filled;
	}

	/** gets color */
	public String getColor() 
        {
		return color;
	}

	/** Sets color */
	public void setColor(String color) 
        {
		this.color = color;
	}

	/** is filled Boolean  */
	public boolean isFilled() 
        {
		return filled;
	}

	/** Sets filled */
	public void setFilled(boolean filled)
        {
		this.filled = filled;
	}

	/** gets dateCreated */
	public java.util.Date getDateCreated() 
        {
		return dateCreated;
	}

	/** to string method for geometric object */
	public String toString() 
        {
		return "created on " + dateCreated + "\ncolor: " + color + " and filled: " + filled;
	}
}

