/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Details;

/**
 * @author Kushal Satya Durgaji Katari
 */

public class Main {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
       System.out.println("Answer for question 5 : Kushal Katari");
       Person person = new Person("David Hussey", "cleavland park", "928-849-6578", "dhussey04@yahoo.com");
       Student student = new Student("chole mortez", "north 11 garden", "476-575-3346", "cholemortez@gmail.com","Pass" ,"Graduate");
       Employee  employee = new Employee("harshal","Devunithota street","660-528-1390","harshalk@gmail.com","Cerner",10000,"04/17/2018");
       Faculty faculty = new Faculty("sahi","crea museam", "758-738-7349","sahivar@gmail.com","google",15756,"09/27/2015",9,5);
       Staff staff = new Staff("john williams"," canal road","859-763-8628","johnw0909@orkut.com","microsoft",5500,"06/12/2019","Sales Officer");

		System.out.println(person.toString());
		System.out.println(student.toString());
		System.out.println(employee.toString());
		System.out.println(faculty.toString());
		System.out.println(staff.toString());
                
		}
                }

    