/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Details;

/**
 * @author Kushal Satya Durgaji Katari
 */

        public class Faculty extends Employee
        {
        double office_hours;
        int numberOf_TeachingSubjects;
        
        public Faculty(String name, String address, String phone, String email, String office, double salary,
        String date_hired,double office_hours, int numberOfCoursesTeaching)
        {
	super(name, address, phone, email, office, salary, date_hired);
	this.office_hours = office_hours;
	this.numberOf_TeachingSubjects = numberOf_TeachingSubjects;
        }
        
        @Override
        public String toString()
        {
	return "Faculty [office_hours: " +office_hours+ ", numberOf_TeachingSubjects: " +
        numberOf_TeachingSubjects+ ", office: " +office+ ", salary: " +salary+ ", date_hired: " + 
        date_hired + ", name: " +name+ ", address: " +address+ ", phone: " +phone+ ", email: " +email+ "]";
        }
        }

