/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Details;

/**
 * @author Kushal Satya Durgaji Katari
 */

       public class Person 
       {
         String name;
         String address;
         String phone;
         String email;
         
       public Person(String name, String address, String phone, String email) 
       {
	super();
	this.name = name;
	this.address = address;
	this.phone = phone;
	this.email = email;
       }
          @Override
        public String toString()
        {
	return "Person [name: " +name+ ", address: " +address+ ", phone: " +phone+ ", email: " +email+ "]";
        }
        }

    

