/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Details;

/**
 * @author Kushal Satya Durgaji Katari
 */
public class Employee extends Person
        {
	String office;
	double salary;
	String date_hired;
        
	@Override
	public String toString()
        {
	return "Employee [office: " +office+ ", salary: " +salary+ ", date_hired: " +date_hired+ ", name: " +name
	+ ", address: " +address+ ", phone: " +phone+ ", email: " + email+ "]";
	}
        
	public Employee(String name, String address, String phone, String email, String office, double salary,String date_hired) {
	super(name, address, phone, email);
	this.office = office;
	this.salary = salary;
	this.date_hired = date_hired;
	}	
        }
