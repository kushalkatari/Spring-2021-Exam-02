/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Details;

/**
 * @author Kushal Satya Durgaji Katari
 */

         public class Student extends Person 
         {
	 String grade;
	 String class_status;

	public Student(String name, String address, String phone, String email, String grade, String class_status ) 
        {
	super(name, address, phone, email);
	grade = grade;
	class_status = class_status;
	}

	@Override
	public String toString()
        {
	return "Student [Grade: " +grade+ ", class_status: " +class_status+ ", name: " +name+ ", address: " 
                +address+ ", phone: "+ phone+ ", email: " +email+"]";
	}
        }

	


