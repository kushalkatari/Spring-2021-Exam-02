/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArrayList;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
public class DistinctIntegers {
    /** Main method */
	public static void main(String[] args) {
		//  scanner is created
		Scanner sc = new Scanner(System.in);
		//  ArrayList is created
		ArrayList<Integer> list = new ArrayList<Integer>();

		// statement to enter 10 integers
                System.out.println("Answer for question 1: Kushal Katari");
		System.out.print("Enter ten integers: ");
		for (int i = 0; i < 10; i++) 
                {
	         list.add(sc.nextInt());
		}
		removeDuplicate(list);

		// To know what the distinct integers are.
		System.out.print("The distinct integers are ");
		for (int i = 0; i < list.size(); i++) 
                {
		System.out.print(list.get(i) + " ");
		}
		System.out.println();
	        }

	/**statement to remove the  duplicate elements from an array list of integers **/
	public static void removeDuplicate(ArrayList<Integer> list) 
        {
	for (int i = 0; i < list.size() - 1; i++) 
        {
	for (int j = i + 1; j < list.size(); j++) 
        {
	if (list.get(i) == list.get(j))
	list.remove(j);
	}
	}
	}
        }

