/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;
import java.util.Scanner;

/**
 * @author Kushal Satya Durgaji Katari
 */

// An Enum class
enum Eatbles
{
    PIZZA, RICE, FRUITS,ICECREAMS,
    VEGATABLES, CHICKEN, PORK;
}
  
// Driver class that contains an object of "eatbles" and
// main().
public class Test
{
    Eatbles eatbles;
  
    // Constructor
    public Test(Eatbles eatbles)
    {
        this.eatbles = eatbles;
    }
  
    // Prints a line about eatbles using switch
    public void dayWithEatbles()
    {
        switch (eatbles)
        {
        case PIZZA:
            System.out.println("PIZZAS are good.");
            break;
        case RICE:
            System.out.println("RICE is Happiness.");
            break;
        case FRUITS:
            System.out.println("FRUITS are good for Health.");
            break;
        case PORK:
            System.out.println("PORK is not at all good.");
            break;
        default:
            System.out.println("This are smooth and very tasty.");
            break;
        }
    }
}

