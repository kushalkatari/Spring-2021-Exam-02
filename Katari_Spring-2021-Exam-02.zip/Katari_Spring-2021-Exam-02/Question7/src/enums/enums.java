/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
     public class enums 
    {
        
    /**
     * @param args the command line arguments
     */

    // TODO code application logic here
         public static void main(String[] args)
    {
        System.out.println("Answer for question 7: Kushal Katari");
        String str = "PIZZA";
        Test t1 = new Test(Eatbles.valueOf(str));
        t1.dayWithEatbles();
    }
    }
       

 
