/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cars;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
        // TODO code application logic here
    
    public static void main(String args[])
    {
        System.out.println("Answer for question 4 : Kushal Katari");
        SuperCar sc = new SuperCar(9, 700,80);
        System.out.println(sc.toString());
    }
    }
    
    

