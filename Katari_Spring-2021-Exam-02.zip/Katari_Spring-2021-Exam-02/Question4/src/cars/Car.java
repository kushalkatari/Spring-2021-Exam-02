/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cars;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
    public class Car 
    {
    
    //  car class has two fields
    public int colors;
    public int speed;
 
    //  car class has one constructor
    public Car(int colors, int speed)
    {
        this.colors = colors;
        this.speed = speed;
    }
 
    //car class has  three methods
    public void force(int decrement)
    {
        speed = speed-decrement;
    }
 
    public void speed(int increment)
    {
        speed = speed+increment;
    }
 
    // toString() method for car
    public String toString()
    {
        return ("No of colors are " + colors + "\n"+ "Speed of car is " + speed);
    }
}
 

