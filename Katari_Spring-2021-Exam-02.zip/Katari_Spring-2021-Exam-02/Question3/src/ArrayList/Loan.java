/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArrayList;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
        public class Loan 
        {    
	private int amount;
	private double interestRate;
	public Loan() 
        {
	this(400,50);
	}
	public Loan( int amount, double intrestRate) 
        {
		super();
		this.amount = amount;
		this.interestRate = intrestRate;
	}
	@Override
	public String toString() 
        {
	return "LoanAmount=" + amount + ", InterestRate=" + interestRate + "";
	}
	public int getAmount() 
        {
	return amount;
	}
	public void setAmount(int amount)
        {
	this.amount = amount;
	}
	public double getInterestRate()
        {
	return interestRate;
	}
	public void setInterestRate(double interestRate) 
        {
	this.interestRate = interestRate;
	}
        }

    

