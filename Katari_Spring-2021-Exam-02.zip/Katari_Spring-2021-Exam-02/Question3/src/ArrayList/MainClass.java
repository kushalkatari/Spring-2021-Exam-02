/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArrayList;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
public class MainClass 
        {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Array List is created
        System.out.println("Answer for question 3 : Kushal Katari");
	ArrayList<Object> obj = new ArrayList<Object>();
	obj.add(new Loan());		
	obj.add(new Date());		
	obj.add(new String("String class"));	
	obj.add(new Circle());	
	// To display elements by using to string method
	for (int i = 0; i < obj.size(); i++) 
        {               
	System.out.println((obj.get(i)).toString());
	}
	}
        }
    
